Loading the data:

[y,t] = readfile(name)

where “name” is a string containing the path to the file.