function [ Ixx ] = Ixxfn( X )
%IXXFN Summary of this function goes here
%   Detailed explanation goes here
Xdtft = fft(X);
N = numel(X);
Ixx = ((1/N) .* (abs(Xdtft).^2));

end

