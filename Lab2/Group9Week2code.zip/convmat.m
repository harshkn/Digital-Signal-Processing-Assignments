function [ y] = convmat( x,h )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
y = conv(x,h);

end

